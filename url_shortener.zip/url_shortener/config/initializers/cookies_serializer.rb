# Be sure to restart your server when you modify this file.

Rails.application.config.action_dispatch.cookies_serializer = :json
